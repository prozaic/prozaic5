TrueTypeFont: TH3 MACHINE
Dennis Ludlow 2015 all rights reserved
Sharkshock Productions
dennis@sharkshock.net

Meet TH3 MACHINE: Twisted..Irregular...Unassuming...Futuristic? Maybe even a bit apocalyptic. Whatever reason you downloaded it for BEWARE and PROCEED with CAUTION. This font is better suited
for say a title or band name than conversational text. Some of the glyphs are purposefully difficult to read and lean on their "less destroyed" characters for legibility in context. Basic 
punctuation, European accents, and kerning are included. If you're interested in adding Eastern European characters, extended Latin, Cyrillic etc. contact me for pricing as these would have to be
drawn from scratch.

This font is free for any non commerical use. For commercial use please contact me at dennis@sharkshock.net to discuss an end user license. I also design logos so drop me a line!
I accept donations at the same address via paypal. Your support is very much appreciated. Thanks for having a look!

